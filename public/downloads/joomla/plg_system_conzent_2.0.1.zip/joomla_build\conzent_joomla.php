<?php

/**
 * @package     Conzent CMP
 * @subpackage  plg_system_conzent
 * @version     2.0.0
 * @author      Conzent ApS
 * @copyright   Copyright (C) 2025 Conzent ApS. All rights reserved.
 * @license     GNU/GPLv3 https://www.gnu.org/licenses/gpl-3.0.html
 * @link        https://conzent.net/
 *
 * Conzent CMP — Cookie Banner & Consent Management for Joomla 4/5.
 * GDPR, CCPA & ePrivacy compliant cookie banner. IAB TCF v2.2 and
 * Google CMP Certified. Supports self-hosted (OCI) and Conzent Cloud.
 *
 * INSTALLATION:
 * 1. Create folder structure:
 *      plugins/system/conzent/
 *        ├── conzent.php           (this file)
 *        ├── conzent.xml           (manifest — see below)
 *        └── language/en-GB/
 *              └── plg_system_conzent.ini
 *
 * 2. Create conzent.xml manifest:
 *
 *    <?xml version="1.0" encoding="utf-8"?>
 *    <extension type="plugin" group="system" method="upgrade">
 *      <name>plg_system_conzent</name>
 *      <author>Conzent ApS</author>
 *      <authorUrl>https://conzent.net/</authorUrl>
 *      <version>2.0.0</version>
 *      <description>GDPR, CCPA &amp; ePrivacy compliant cookie banner. IAB TCF v2.2 and Google CMP Certified.</description>
 *      <files>
 *        <filename plugin="conzent">conzent.php</filename>
 *        <folder>language</folder>
 *      </files>
 *      <config>
 *        <fields name="params">
 *          <fieldset name="basic">
 *            <field name="website_key" type="text"
 *              label="Website Key"
 *              description="Find this in your Conzent dashboard under Site Settings."
 *              default="" />
 *            <field name="server_url" type="url"
 *              label="Server URL"
 *              description="Leave empty for Conzent Cloud. For self-hosted (OCI), enter your server URL."
 *              default=""
 *              hint="https://app.getconzent.com" />
 *          </fieldset>
 *        </fields>
 *      </config>
 *    </extension>
 *
 * 3. Install via Joomla admin: Extensions → Manage → Install
 *    Or discover: Extensions → Manage → Discover → click Discover, then install.
 * 4. Enable: Extensions → Plugins → search "Conzent" → enable.
 * 5. Configure: Click plugin name → set Website Key.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Application\SiteApplication;

/**
 * Conzent CMP System Plugin.
 *
 * Injects the Conzent banner script into every frontend page.
 */
class PlgSystemConzent extends CMSPlugin
{
    /**
     * Auto-load language files.
     *
     * @var bool
     */
    protected $autoloadLanguage = true;

    /**
     * Plugin version.
     */
    const VERSION = '2.0.0';

    /* ─── Helpers ──────────────────────────────────────────────────── */

    /**
     * Get the configured Conzent server URL (trailing slash stripped).
     */
    private function getServerUrl(): string
    {
        $url = trim($this->params->get('server_url', ''));
        if (empty($url)) {
            $url = 'https://app.getconzent.com';
        }
        return rtrim($url, '/');
    }

    /**
     * Get the API base URL.
     */
    private function getApiUrl(): string
    {
        return $this->getServerUrl() . '/api/v1';
    }

    /**
     * Verify the website key against the Conzent API.
     *
     * @param  string $websiteKey
     * @return array  Site info on success, empty array on failure.
     */
    private function verifyWebsite(string $websiteKey): array
    {
        $apiUrl = $this->getApiUrl() . '/verify?website_id=' . rawurlencode($websiteKey);

        try {
            $http     = HttpFactory::getHttp();
            $response = $http->get($apiUrl, [], 10);

            if ((int) $response->code !== 200) {
                return [];
            }

            $data = json_decode($response->body, true);
            if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
                return [];
            }
            return $data;
        } catch (\Exception $e) {
            return [];
        }
    }

    /* ─── Event: onBeforeCompileHead ───────────────────────────────── */

    /**
     * Inject Conzent banner script into <head>.
     *
     * Fires on every frontend page before the <head> is compiled.
     */
    public function onBeforeCompileHead(): void
    {
        $app = Factory::getApplication();

        // Only run on the frontend (site) application.
        if (!$app instanceof SiteApplication) {
            return;
        }

        $websiteKey = trim($this->params->get('website_key', ''));
        if (empty($websiteKey)) {
            return;
        }

        $serverUrl  = $this->getServerUrl();
        $document   = $app->getDocument();

        // Ensure we have an HtmlDocument.
        if ($document->getType() !== 'html') {
            return;
        }

        // ── Conzent banner script (must be first in <head>) ──
        $bannerSrc = htmlspecialchars(
            $serverUrl . '/c/consent.js',
            ENT_QUOTES,
            'UTF-8'
        );
        $bannerKey = htmlspecialchars($websiteKey, ENT_QUOTES, 'UTF-8');
        $document->addCustomTag(
            '<script async src="' . $bannerSrc . '" data-key="' . $bannerKey . '"></script>'
        );
    }

    /* ─── Event: onExtensionAfterSave (verify on settings save) ──── */

    /**
     * Verify website key whenever the plugin settings are saved.
     *
     * This is called by Joomla's extension save pipeline.
     */
    public function onExtensionAfterSave(string $context, $table, bool $isNew): void
    {
        if ($context !== 'com_plugins.plugin') {
            return;
        }

        // Check if this is our plugin being saved.
        if (!isset($table->element) || $table->element !== 'conzent') {
            return;
        }

        $decoded = json_decode($table->params ?? '{}', true);
        if (!is_array($decoded) || json_last_error() !== JSON_ERROR_NONE) {
            return;
        }
        $params     = $decoded;
        $websiteKey = trim($params['website_key'] ?? '');

        if (!empty($websiteKey)) {
            $siteInfo = $this->verifyWebsite($websiteKey);

            if (!empty($siteInfo) && isset($siteInfo['domain'])) {
                $params['verified']   = 'yes';
                $params['site_name']  = $siteInfo['site_name'] ?? '';
                $params['site_domain'] = $siteInfo['domain'] ?? '';
                $params['site_id']    = (string) ($siteInfo['id'] ?? '');
            } else {
                // API unreachable — still allow banner to load.
                $params['verified'] = 'yes';
            }
        } else {
            $params['verified'] = '';
        }

        $table->params = json_encode($params);
        $table->store();
    }
}
